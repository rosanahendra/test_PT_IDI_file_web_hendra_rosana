-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 13, 2022 at 06:27 PM
-- Server version: 10.5.16-MariaDB-cll-lve
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u7029827_test_mock_up`
--

-- --------------------------------------------------------

--
-- Table structure for table `company_profile`
--

CREATE TABLE `company_profile` (
  `comp_id` int(11) NOT NULL,
  `comp_code` varchar(50) NOT NULL,
  `comp_name` varchar(255) NOT NULL,
  `comp_url` varchar(255) NOT NULL,
  `comp_logo` longtext NOT NULL,
  `comp_address` longtext NOT NULL,
  `comp_phone` varchar(70) NOT NULL,
  `comp_handphone` varchar(70) NOT NULL,
  `comp_fax` varchar(70) NOT NULL,
  `comp_email` varchar(200) NOT NULL,
  `comp_description` longtext NOT NULL,
  `comp_time_reservation` int(11) NOT NULL,
  `comp_status_reservation` enum('Aktif','Non-Aktif') NOT NULL,
  `comp_fb` longtext NOT NULL,
  `comp_ig` longtext NOT NULL,
  `comp_twitter` longtext NOT NULL,
  `comp_youtube` longtext NOT NULL,
  `comp_tiktok` longtext NOT NULL,
  `comp_color` varchar(50) NOT NULL,
  `comp_protocol` varchar(150) NOT NULL,
  `comp_smtp_host` varchar(150) NOT NULL,
  `comp_smtp_port` varchar(150) NOT NULL,
  `comp_smtp_crypto` varchar(150) NOT NULL,
  `comp_smtp_user` varchar(150) NOT NULL,
  `comp_smtp_pass` varchar(150) NOT NULL,
  `comp_email_status` enum('Tidak Aktif','Aktif') NOT NULL,
  `comp_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_profile`
--

INSERT INTO `company_profile` (`comp_id`, `comp_code`, `comp_name`, `comp_url`, `comp_logo`, `comp_address`, `comp_phone`, `comp_handphone`, `comp_fax`, `comp_email`, `comp_description`, `comp_time_reservation`, `comp_status_reservation`, `comp_fb`, `comp_ig`, `comp_twitter`, `comp_youtube`, `comp_tiktok`, `comp_color`, `comp_protocol`, `comp_smtp_host`, `comp_smtp_port`, `comp_smtp_crypto`, `comp_smtp_user`, `comp_smtp_pass`, `comp_email_status`, `comp_date`) VALUES
(1, 'RUBI2022', 'Test Form', 'test.bioskopverse.com', 'asset/image/logo-new.png', 'Jl. Soekarno Hatta, Ruko Metro Indah Mall Blok I No. 27, - 40286 ', '0227535733', '081280002840', '', 'csrubitour@gmail.com', 'Rubi Tour Operator adalah perusahaan jasa penyedia layanan untuk biro perjalanan wisata dan berfokus pada destinasi Internasional, baik wisata muslim maupun leisure. <br />\r\n<br />\r\nTim kami dapat mengatur untuk menyediakan keperluan wisata sesuai kebutuhan dari para travel agent baik untuk pemerintahan, pelajar, pribadi, keluarga maupun perjalanan bisnis perusahaan swasta.<br />\r\n<br />\r\nRubi sebagai Tour Operator Internasional juga mengadakan paket-paket konsorsium ke berbagai negara yang bisa di ikuti oleh para travel agent. Jaringan kami mencakup diantaranya sektor : Asia, Eropa, UK, Middle East, Amerika dan Australia.<br />\r\n<br />\r\nBeberapa travel agent yang telah memakai jasa kami diantaranya :<br />\r\n<br />\r\nMunatour, Cheria Travel , Mozaik Travel , Khalifa Tour, Qiblat Tour, Percikan Iman, Gema Raudhah, Mazq Tour, Maqdis Tour, Gelora Indah Wisata, Darul Iman Travel, Andalus Travel, Arofah Mina Travel, Pancar Tour, Idah Roes Tour, dan masih banyak lagi travel agent di wilayah pulau Jawa, Sumatera, Kalimantan dan Sulawesi. <br />\r\n<br />\r\nPerusahaan ini dijalankan dan di kelola oleh tim kami yang profesional dan bertanggung jawab', 3, 'Aktif', 'facebooks.com', 'instagram.com', '', 'youtubers.com', 'tiktok.com', '#f2184f', 'smtp', 'amoures.id', '465', 'ssl', 'info@amoures.id', 'admin2020', 'Aktif', '2022-07-23');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `memb_id` int(11) NOT NULL,
  `usrs_id` int(11) NOT NULL,
  `memb_position` varchar(200) NOT NULL,
  `memb_ktp` varchar(100) NOT NULL,
  `memb_city` varchar(150) NOT NULL,
  `memb_name` varchar(255) NOT NULL,
  `memb_asal_lahir` varchar(100) NOT NULL,
  `memb_birthdate` date NOT NULL,
  `memb_phone` varchar(50) NOT NULL,
  `memb_agama` varchar(50) NOT NULL,
  `memb_gender` enum('Laki-Laki','Perempuan') NOT NULL,
  `memb_golongan_darah` enum('A','B','AB','O') NOT NULL,
  `memb_status` enum('Belum Kawin','Sudah Kawin') NOT NULL,
  `memb_address` varchar(255) NOT NULL,
  `memb_address_ktp` varchar(255) NOT NULL,
  `memb_nama_orang_terdekat` varchar(120) NOT NULL,
  `memb_skill` longtext NOT NULL,
  `memb_bersedia_penempatan` enum('YA','TIDAK') NOT NULL,
  `memb_salary` bigint(30) NOT NULL,
  `memb_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`memb_id`, `usrs_id`, `memb_position`, `memb_ktp`, `memb_city`, `memb_name`, `memb_asal_lahir`, `memb_birthdate`, `memb_phone`, `memb_agama`, `memb_gender`, `memb_golongan_darah`, `memb_status`, `memb_address`, `memb_address_ktp`, `memb_nama_orang_terdekat`, `memb_skill`, `memb_bersedia_penempatan`, `memb_salary`, `memb_date`) VALUES
(1, 1, '2', '1', '', 'Admin', 'bandung', '2022-07-31', '', 'Islam', 'Laki-Laki', 'AB', 'Belum Kawin', 'Antapani', '', 'hendra', '', 'YA', 0, '2022-08-13 11:06:36'),
(155, 161, 'Programmer', '112233', '', 'Saffron', 'Bandung', '2022-08-30', '0811223344', 'Islam', '', 'A', 'Sudah Kawin', 'Jalan asli', 'Jalan ktp', 'irma', '', 'YA', 2500000, '2022-08-13 11:19:05'),
(156, 163, '', '', '', '', '', '0000-00-00', '', '', 'Laki-Laki', 'A', 'Belum Kawin', '', '', '', '', 'YA', 0, '2022-08-13 11:20:54'),
(157, 164, 'Programmer', '223344', '', 'Member 2', 'Soreang', '2022-08-01', '0833445566', 'Islam', 'Laki-Laki', 'AB', 'Sudah Kawin', 'Jalan asli aja', 'Jalan ktp ajah', 'dede', '', 'TIDAK', 4500000, '2022-08-13 11:22:58');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menu_id` int(15) NOT NULL,
  `menu_parent_id` int(15) NOT NULL,
  `menu_title` varchar(150) NOT NULL,
  `menu_url` longtext NOT NULL,
  `menu_menu_order` int(15) NOT NULL,
  `menu_faIcon` varchar(100) NOT NULL,
  `menu_C` int(15) NOT NULL,
  `menu_R` int(15) NOT NULL,
  `menu_U` int(15) NOT NULL,
  `menu_D` int(15) NOT NULL,
  `menu_printing` int(15) NOT NULL,
  `menu_detail` int(15) NOT NULL,
  `menu_display` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `menu_parent_id`, `menu_title`, `menu_url`, `menu_menu_order`, `menu_faIcon`, `menu_C`, `menu_R`, `menu_U`, `menu_D`, `menu_printing`, `menu_detail`, `menu_display`) VALUES
(3, 0, 'Pengguna', 'users', 1, 'user-secret', 1, 1, 1, 1, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu_access`
--

CREATE TABLE `menu_access` (
  `meac_id` int(10) NOT NULL,
  `user_id` int(20) NOT NULL,
  `menu_id` bigint(5) NOT NULL,
  `meac_C` int(5) NOT NULL,
  `meac_R` int(5) NOT NULL,
  `meac_U` int(5) NOT NULL,
  `meac_D` int(5) NOT NULL,
  `meac_printing` int(5) NOT NULL,
  `meac_detail` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_access`
--

INSERT INTO `menu_access` (`meac_id`, `user_id`, `menu_id`, `meac_C`, `meac_R`, `meac_U`, `meac_D`, `meac_printing`, `meac_detail`) VALUES
(3, 1, 3, 1, 1, 1, 1, 0, 0),
(34, 2, 3, 1, 1, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pekerjaan`
--

CREATE TABLE `pekerjaan` (
  `peke_id` int(11) NOT NULL,
  `memb_id` int(11) NOT NULL,
  `peke_perusahaan` varchar(100) NOT NULL,
  `peke_posisi` varchar(200) NOT NULL,
  `peke_salary` varchar(20) NOT NULL,
  `peke_tahun` varchar(10) NOT NULL,
  `peke_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pekerjaan`
--

INSERT INTO `pekerjaan` (`peke_id`, `memb_id`, `peke_perusahaan`, `peke_posisi`, `peke_salary`, `peke_tahun`, `peke_date`) VALUES
(1, 153, 'pt kolang', 'divisi it', '2000000', '2023', '0000-00-00 00:00:00'),
(2, 153, 'PT maju', 'sistem analisis', '2500000', '2024', '0000-00-00 00:00:00'),
(3, 153, 'PT sahaja', 'QA', '300000', '2025', '0000-00-00 00:00:00'),
(5, 154, 'pt kolang', 'divisi it', '2000000', '2023', '2022-08-13 11:11:15'),
(6, 154, 'PT maju', 'sistem analisis', '2500000', '2024', '2022-08-13 11:11:15'),
(7, 155, 'pt kolang', 'divisi it', '2000000', '2023', '2022-08-13 11:18:56'),
(8, 155, 'pt kolang', 'sistem analisis', '2500000', '2024', '2022-08-13 11:18:56'),
(9, 157, 'pt kolang', 'divisi it', '2000000', '2023', '0000-00-00 00:00:00'),
(10, 157, 'PT maju', 'sistem analisis', '2500000', '2024', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pelatihan`
--

CREATE TABLE `pelatihan` (
  `pela_id` int(11) NOT NULL,
  `memb_id` int(11) NOT NULL,
  `pela_kursus` longtext NOT NULL,
  `pela_sertifikat` enum('Ada','Tidak') NOT NULL,
  `pela_tahun` varchar(10) NOT NULL,
  `pela_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelatihan`
--

INSERT INTO `pelatihan` (`pela_id`, `memb_id`, `pela_kursus`, `pela_sertifikat`, `pela_tahun`, `pela_date`) VALUES
(1, 153, 'codeigniter', 'Ada', '2022', '0000-00-00 00:00:00'),
(2, 153, '', 'Ada', '2021', '0000-00-00 00:00:00'),
(3, 153, 'SAP', 'Tidak', '2023', '0000-00-00 00:00:00'),
(4, 153, 'flutter', 'Ada', '2024', '0000-00-00 00:00:00'),
(6, 154, 'codeigniter', 'Ada', '2022', '2022-08-13 11:11:15'),
(7, 154, 'SAP', 'Tidak', '2023', '2022-08-13 11:11:15'),
(8, 155, 'codeigniter', 'Ada', '2022', '2022-08-13 11:18:56'),
(9, 155, 'SAP', 'Tidak', '2023', '2022-08-13 11:18:56'),
(10, 157, 'codeigniter', 'Ada', '2022', '0000-00-00 00:00:00'),
(11, 157, 'SAP', 'Tidak', '2023', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE `pendidikan` (
  `pend_id` int(11) NOT NULL,
  `memb_id` int(11) NOT NULL,
  `pend_pendidikan_terakhir` enum('SMK','SMA','D3','D4','S1','S2','S3') NOT NULL,
  `pend_institusi` varchar(255) NOT NULL,
  `pend_jurusan` varchar(150) NOT NULL,
  `pend_tahun_lulus` varchar(10) NOT NULL,
  `pend_ipk` varchar(20) NOT NULL,
  `pend_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendidikan`
--

INSERT INTO `pendidikan` (`pend_id`, `memb_id`, `pend_pendidikan_terakhir`, `pend_institusi`, `pend_jurusan`, `pend_tahun_lulus`, `pend_ipk`, `pend_date`) VALUES
(1, 153, 'SMK', 'smk 1 bandung', 'ipa', '2011', '', '0000-00-00 00:00:00'),
(2, 153, 'D3', 'polban', 'teknik listrik', '2012', '', '0000-00-00 00:00:00'),
(3, 153, 'S1', 'telkom', 'informatika', '2013', '', '0000-00-00 00:00:00'),
(5, 154, 'SMK', 'smk 1 bandung', 'ipa', '2011', '3', '2022-08-13 11:11:15'),
(6, 154, 'D3', 'polban', 'ipa', '2012', '4', '2022-08-13 11:11:15'),
(7, 155, 'SMA', 'smk 1 bandung', 'ipa', '2011', '', '2022-08-13 11:18:56'),
(8, 155, 'S1', 'polban', 'teknik listrik', '2012', '', '2022-08-13 11:18:56'),
(9, 157, 'S1', 'smk 1 bandung', 'ipa', '2011', '', '0000-00-00 00:00:00'),
(10, 157, 'S2', 'polban', 'teknik listrik', '2012', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(15) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `date` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `date`) VALUES
(1, 'Admin', '2022-07-11 12:57:42'),
(2, 'Pelamar', '2022-08-13 11:07:26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `usrs_id` int(10) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `usrs_email` varchar(150) NOT NULL,
  `usrs_password` longtext NOT NULL,
  `usrs_image` longtext NOT NULL,
  `usrs_date` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`usrs_id`, `user_id`, `usrs_email`, `usrs_password`, `usrs_image`, `usrs_date`) VALUES
(1, '1', 'admin@gmail.com', '81fccaf9f00a8441b77b18fa2c8010f4', 'asset/331312180636chat.png', '2022-08-13 11:06:36'),
(161, '2', 'user@gmail.com', '81fccaf9f00a8441b77b18fa2c8010f4', 'asset/862143181856sms.png', '2022-08-13 11:18:56'),
(163, '2', 'user1@gmail.com', '81fccaf9f00a8441b77b18fa2c8010f4', '', '2022-08-13 11:20:54'),
(164, '2', 'baru@gmail.com', 'ee61e766467546320854c3446ccde3d4', 'asset/862017182258reseller.png', '2022-08-13 11:22:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company_profile`
--
ALTER TABLE `company_profile`
  ADD PRIMARY KEY (`comp_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`memb_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `menu_access`
--
ALTER TABLE `menu_access`
  ADD PRIMARY KEY (`meac_id`);

--
-- Indexes for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  ADD PRIMARY KEY (`peke_id`);

--
-- Indexes for table `pelatihan`
--
ALTER TABLE `pelatihan`
  ADD PRIMARY KEY (`pela_id`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`pend_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`usrs_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company_profile`
--
ALTER TABLE `company_profile`
  MODIFY `comp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `memb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menu_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `menu_access`
--
ALTER TABLE `menu_access`
  MODIFY `meac_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  MODIFY `peke_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pelatihan`
--
ALTER TABLE `pelatihan`
  MODIFY `pela_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pendidikan`
--
ALTER TABLE `pendidikan`
  MODIFY `pend_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `usrs_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
